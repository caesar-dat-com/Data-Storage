package com.apiweb.backend.Model.ENUM;

public enum Sexo {
    hombre,mujer
}

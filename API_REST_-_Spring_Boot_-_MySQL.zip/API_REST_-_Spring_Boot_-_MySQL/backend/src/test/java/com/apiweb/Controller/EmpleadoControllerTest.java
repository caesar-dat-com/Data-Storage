import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.apiweb.backend.Controller.EmpleadoController;
import com.apiweb.backend.Model.EmpleadoModel;
import com.apiweb.backend.Service.IEmpleadoService;

public class EmpleadoControllerTest {

    @Test
    public void testCrearEmpleado() {
        // Creamos el modelo de empleado
        EmpleadoModel empleado = new EmpleadoModel();
        empleado.setNombre("Juan");
        empleado.setApellidos("Perez");
        
        // Mockeamos el servicio
        IEmpleadoService empleadoServiceMock = mock(IEmpleadoService.class);
        when(empleadoServiceMock.guardarEmpleado(empleado)).thenReturn("Empleado creado correctamente");

        // Creamos el controlador y le pasamos el servicio mockeado
        EmpleadoController empleadoController = new EmpleadoController();
        empleadoController.empleadoService = empleadoServiceMock;
        
        // Llamamos al método del controlador
        ResponseEntity<String> response = empleadoController.crearEmpleado(empleado);
        
        // Imprimimos un mensaje para verificar la ejecución
        System.out.println("Prueba ejecutada correctamente, respuesta del controlador: " + response.getBody());

        // Comprobamos si el controlador funcionó
        assertEquals(HttpStatus.OK, response.getStatusCode(), "Error en el controlador");
        assertEquals("Empleado creado correctamente", response.getBody(), "Error en el servicio");

        // Comprobamos si el servicio guardó al empleado
        verify(empleadoServiceMock, times(1)).guardarEmpleado(empleado);
    }
}
